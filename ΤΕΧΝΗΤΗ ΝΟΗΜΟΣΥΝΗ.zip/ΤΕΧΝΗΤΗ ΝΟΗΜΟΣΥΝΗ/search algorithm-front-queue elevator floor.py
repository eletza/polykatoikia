""" ----------------------------------------------------------------------------
******** Search Code for DFS  and other search methods
******** (expanding front only)
******** author:  AI lab
********
******** Κώδικας για α DFS και άλλες μεθόδους αναζήτησης
******** (επέκταση μετώπου μόνο)
******** Συγγραφέας: Εργαστήριο ΤΝ
"""

import copy

import sys 
  
sys.setrecursionlimit(10**6) 

# ******** Operators
# ******** Τελεστές
#Δημιουργία τελεστή ταράτσας
def go_to_roof(state):
    if state[-1] == 8 or (state[1] == 0 and state[2] == 0 and state[3] == 0 and state[4] == 0):
       new_state = [5, state[1], state[2], state[3], state[4], 0]
       return new_state
#Δημιουργία τελεστή πρώτου ορόφου
def go_to_floor1(state):
    if state[-1]<8 and state[1]>0:
        if state[1]>8-state[-1]:
            new_state = [1] + [state[1] + state[-1] - 8] + [state[2]] + [state[3]] + [state[4]] + [8]
        else:
            new_state = [1] + [0] + [state[2]] + [state[3]] + [state[4]] + [state[1] + state[-1]]
        return new_state
#Δημιουργία τελεστή δεύτερου ορόφου
def go_to_floor2(state):
    if state[-1]<8 and state[2]>0:
        if state[2]>8-state[-1]:
            new_state = [1+1] + [state[1]] + [state[2] + state[-1] - 8] + [state[3]] + [state[4]] + [8]
        else:
            new_state = [1+1] + [state[1]] + [0] + [state[3]] + [state[4]] + [state[2] + state[-1]]
        return new_state
#Δημιουργία τελεστή τρίτου ορόφου
def go_to_floor3(state):
    if state[-1]<8 and state[3]>0:
        if state[3]>8-state[-1]:
            new_state = [1+1+1] + [state[1]] + [state[2]] + [state[3] + state[-1] - 8]  + [state[4]] + [8]
        else:
            new_state = [1+1+1] + [state[1]] + [state[2]] + [0] + [state[4]] + [state[3] + state[-1]]
        return new_state
#Δημιουργία τελεστή τέταρτου ορόφου
def go_to_floor4(state):
    if state[-1]<8 and state[4]>0:
        if state[4]>8-state[-1]:
            new_state = [1+1+1+1] + [state[1]] + [state[2]] + [state[3]] + [state[4] + state[-1] - 8]  + [8]

        else:
            new_state = [1+1+1+1] + [state[1]] + [state[2]] + [state[3]] + [0] + [state[4] + state[-1]]
        return new_state


'''
Συνάρτηση εύρεσης απογόνων της τρέχουσας κατάστασης
'''
def find_children(state):
   #Δημιουργία κενής λίστας
   children=[]
   # Δημιουργία αντιγράφου της κατάστασης για κάθε πιθανή κίνηση
   roof_state=copy.deepcopy(state)
   # Κλήση των συνάρτησης go_to_roof για τη δημιουργία παιδιών
   roof_child=go_to_roof(roof_state)
   # Δημιουργία αντιγράφου της κατάστασης για κάθε πιθανή κίνηση
   floor1_state=copy.deepcopy(state)
    # Κλήση των συνάρτησης go_to_floor1 για τη δημιουργία παιδιών
   floor1_child=go_to_floor1(floor1_state)
   # Δημιουργία αντιγράφου της κατάστασης για κάθε πιθανή κίνηση
   floor2_state=copy.deepcopy(state)
   # Κλήση των συνάρτησης go_to_floor2 για τη δημιουργία παιδιών
   floor2_child=go_to_floor2(floor2_state)
   # Δημιουργία αντιγράφου της κατάστασης για κάθε πιθανή κίνηση
   floor3_state=copy.deepcopy(state)
   # Κλήση των συνάρτησης go_to_floor3 για τη δημιουργία παιδιών
   floor3_child=go_to_floor3(floor3_state)
   # Δημιουργία αντιγράφου της κατάστασης για κάθε πιθανή κίνηση
   floor4_state=copy.deepcopy(state)
   # Κλήση των συνάρτησης go_to_floor4 για τη δημιουργία παιδιών
   floor4_child=go_to_floor4(floor4_state)
   # Προσθέτονται παιδιά στη λίστα, εάν είναι διαφορετικά του None
   if roof_child!=None:
      children.append(roof_child)
   if floor1_child!=None:
      children.append(floor1_child)
   if floor2_child!=None:
      children.append(floor2_child)
   if floor3_child!=None:
      children.append(floor3_child)
   if floor4_child!=None:
      children.append(floor4_child)
   #Επιστρέφεται η λίστα παιδιών
   return children
    


""" ----------------------------------------------------------------------------
**** FRONT
**** Διαχείριση Μετώπου
"""

""" ----------------------------------------------------------------------------
** initialization of front
** Αρχικοποίηση Μετώπου
"""
#Δημιουργία μετώπου αναζήτησης
def make_front(state):
    return [state]
    
""" ----------------------------------------------------------------------------
**** expanding front
**** επέκταση μετώπου    
"""
def weigh_state(state):
    # Η συνάρτηση εκτίμησης είναι η απόσταση των ανθρώπων από την ταράτσα
    return sum(state[1:5])
# Επέκταση του μετώπου αναζήτησης ανάλογα με τη μέθοδο αναζήτησης
def expand_front(front, method):  
    #Αν η μέθοδος είναι DFS
    if method=='DFS':        
        if front:
            print("Front:")
            print(front)
            # Αφαίρεση του πρώτου κόμβου από το μέτωπο
            node=front.pop(0)
             # Εύρεση των παιδιών του κόμβου
            for child in find_children(node):    
                #Εισαγωγή του παιδιού στην αρχή του μετώπου 
                front.insert(0,child)
    #Αν η μέθοδος είναι BFS
    elif method=='BFS':
          if front:
            print("Front:")
            print(front)
            #Αφαίρεση του πρώτου κόμβου από το μέτωπο
            node = front.pop(0)
            #Εύρεση των παιδιών του κόμβου
            for child in find_children(node):
                if child not in front:
                    # Προσθήκη του παιδιού στο τέλος του μέτωπου
                    front.append(child)
    #Αν η μέθοδος είναι BestFS
    elif method=='BestFS':
         if front:
            print("Front:")
            print(front)
            #Αφαίρεση του πρώτου κόμβου από το μέτωπο
            node = front.pop(0)
            #Εύρεση των παιδιών του κόμβου
            for child in find_children(node):
                if child not in front:
                    front.append(child)
            # Ταξινόμηση του μέτωπου βάσει της συνάρτησης κόστους
            front.sort(key=lambda child: weigh_state(child)) 
    #else: "other methods to be added"        
    #επιστρέφεται το μέτωπο
    return front


""" ----------------------------------------------------------------------------
**** QUEUE
**** Διαχείριση ουράς
"""

""" ----------------------------------------------------------------------------
** initialization of queue
** Αρχικοποίηση ουράς
"""
#Δημιουργία ουράς
def make_queue(state):
    return [[state]]

""" ----------------------------------------------------------------------------
**** expanding queue
**** επέκταση ουράς
"""
#Επέκταση ουράς ανάλογα με τη μέθοδο αναζήτησης
def extend_queue(queue, method):
    #Αν η μέθοδος είναι DFS
    if method=='DFS':
        print("Queue:")
        print(queue)
        # Αφαίρεση του πρώτου κόμβου από την ουρά
        node=queue.pop(0)
        queue_copy=copy.deepcopy(queue)
        # Εύρεση των παιδιών του κόμβου
        children=find_children(node[-1])
        for child in children:
            # Δημιουργία νέου μονοπατιού προς το παιδί και προστίθεται στην αρχή της ουράς
            path=copy.deepcopy(node)
            path.append(child)
            queue_copy.insert(0,path)
    # Αν η μέθοδος είναι BFS
    elif method=='BFS':
        print("Queue:")
        print(queue)
        # Αφαίρεση του πρώτου κόμβου από την ουρά
        node=queue.pop(0)
        queue_copy=copy.deepcopy(queue)
        # Εύρεση των παιδιών του κόμβου
        children=find_children(node[-1])
        for child in children:
            # Δημιουργία νέου μονοπατιού προς το παιδί και προστίθεται στο τέλος της ουράς
            path=copy.deepcopy(node)
            path.append(child)
            queue_copy.append(path)
        # Κρατάμε στην ουρά το αντίγραφο
        queue = queue_copy
    elif method=='BestFS':
        if queue:
           print("Queue:")
           print(queue)
            # Αφαίρεση του πρώτου κόμβου από την ουρά
           node = queue.pop(0)
             # Δημιουργία αντιγράφου της ουράς
           queue_copy=copy.deepcopy(queue)
             # Εύρεση των παιδιών του κόμβου
           children=find_children(node[-1])
           for child in children:
           # Δημιουργία νέου μονοπατιού προς το παιδί και προστίθεται στην ουρά
            path = copy.deepcopy(node)
            path.append(child)
            queue_copy.append(path)
           # Ταξινόμηση της ουράς βάσει της συνάρτησης weigh_state
           queue.sort(key=lambda path: weigh_state(path[-1]))
        
    #else: "other methods to be added" 
    
    return queue_copy


""" ----------------------------------------------------------------------------
**** Problem depending functions
**** ο κόσμος του προβλήματος (αν απαιτείται) και υπόλοιπες συναρτήσεις σχετικές με το πρόβλημα

  #### to be  added ####
"""

""" ----------------------------------------------------------------------------
**** Basic recursive function to create search tree (recursive tree expansion)
**** Βασική αναδρομική συνάρτηση για δημιουργία δέντρου αναζήτησης (αναδρομική επέκταση δέντρου)
"""
# Ελέγχει αν η κατάσταση state είναι ο στόχος της αναζήτησης
def is_goal_state(state):
    return state == [5, 0, 0, 0, 0, 0]

#def find_solution(front, queue, closed, goal, method):
def find_solution(front, queue, closed, method):
    #Εάν το front είναι άδειο
    if not front:
        print('_NO_SOLUTION_FOUND_')
    #Εάν ο πρώτος κόμβος του front είναι ήδη στο closed
    elif front[0] in closed:
        new_front=copy.deepcopy(front)
        #αφαιρείται από το front 
        new_front.pop(0)
        new_queue=copy.deepcopy(queue)
        #αφαιρείται από το queue
        new_queue.pop(0)
        #find_solution(new_front, new_queue, closed, goal, method)
        #κλήση της συνάρτησης
        find_solution(new_front, new_queue, closed, method)
    #εαν ο πρώτος κόμβος είναι ο στόχος
    elif is_goal_state(front[0]):
    #elif front[0]==goal:
        print('_GOAL_FOUND_')
        #τυπώνεται η τελική κατάσταση
        print(front[0])
        #τυπώνεται η τελικό μονοπάτι
        print(queue[0])
        
    else:
        # Η κατάσταση του τρέχοντος κόμβου (front[0]) προστίθεται στη λίστα closed.
        closed.append(front[0])
        #Δημιουργείται αντίγραφο λίστας front
        front_copy=copy.deepcopy(front)
        #Εκτελείται η επέκταση του front με τη συνάρτηση expand_front
        front_children=expand_front(front_copy, method)
        #Δημιουργείται αντίγραφο λίστας queue 
        queue_copy=copy.deepcopy(queue)
        #Εκτελείται της queue με τη συνάρτηση expand_queue
        queue_children=extend_queue(queue_copy, method)
         #Δημιουργείται αντίγραφο λίστας closed 
        closed_copy=copy.deepcopy(closed)
        #find_solution(front_children, queue_children, closed_copy, goal, method)
        #Κλήση της συνάρτησης αναζήτησης
        find_solution(front_children, queue_children, closed_copy, method)
        
        
        
"""" ----------------------------------------------------------------------------
** Executing the code
** κλήση εκτέλεσης κώδικα
"""
           
def main():
    #αρχική κατάσταση
    initial_state = [0, 9, 4, 12, 7, 0]
    #τελική κατάσταση
    goal = [5, 0, 0, 0, 0, 0]
    method='DFS'
    
    """ ----------------------------------------------------------------------------
    **** starting search
    **** έναρξη αναζήτησης
    """
    
    print('____BEGIN__SEARCHING____')
    #κλήση συνάρτησης αναζήτησης
    #find_solution(make_front(initial_state), make_queue(initial_state), [], goal, method)
    find_solution(make_front(initial_state), make_queue(initial_state), [], method)
    
    
if __name__ == "__main__":
    main()
